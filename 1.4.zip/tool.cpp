#include "tool.h"

Tool::Tool() {}
