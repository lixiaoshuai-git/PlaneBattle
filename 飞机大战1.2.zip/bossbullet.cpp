#include "bossbullet.h"

BossBullet::BossBullet(qreal _x, qreal _y, qreal _dx, qreal _dy)
    : x(_x), y(_y), dx(_dx), dy(_dy) {
    img.load(":/new/res/boss_bullet.png"); // 加载弹幕图片
}

void BossBullet::update() {
    x += dx;  // 按向量移动
    y += dy;
}

void BossBullet::draw(QPainter& p) {
    p.drawPixmap(x, y, img);  // 绘制弹幕
}

bool BossBullet::out() const {
    // 超出屏幕范围判断
    return x < 0 || x > WIN_W || y < 0 || y > WIN_H;
}

QRectF BossBullet::rect() const {
    return QRectF(x, y, img.width(), img.height());
}
