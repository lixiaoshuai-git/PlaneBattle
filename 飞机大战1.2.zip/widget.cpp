#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QKeyEvent>
#include <QDebug>
#include <QICon>
#include <ctime>
#include <cstdlib>

#include "before.h"
#include "play01.h"
#include "over.h"
#include "map.h"
int Widget::status =0;
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("飞机大战");
    setWindowIcon(QIcon(":/new/res/app.ico"));
    this->resize(600,800);
    //    把最大宽和 高设置成相同
    this->setMinimumWidth(WIN_W);
    this->setMaximumWidth(WIN_W);
    this->setMinimumHeight(WIN_H);
    this->setMaximumHeight(WIN_H);
    //单人
    btn1 = new QPushButton("单人模式", this);
    btn1->move(180, 200);
    btn1->resize(150, 50);
    connect(btn1, &QPushButton::clicked, this, [this](){
        Widget::status = 1;
        play01->plane->hp=100;
        update();
    });

    //双人
    btn2 = new QPushButton("双人合作", this);
    btn2->move(180, 300); // 位置在单人按钮下方
    btn2->resize(150, 50);
    btn2->setVisible(false); // 初始隐藏
    // 绑定点击事件，切换到双人模式（status=2）
    connect(btn2, &QPushButton::clicked, this, [this](){
        Widget::status = 2;
        update();
    });
    //对战
    btn3 = new QPushButton("双人对战", this);
    btn3->move(180, 400); // 位置在双人按钮下方
    btn3->resize(150, 50);
    btn3->setVisible(false); // 初始隐藏
    // 绑定点击事件，切换到双人模式（status=2）
    connect(btn3, &QPushButton::clicked, this, [this](){
        Widget::status = 3;
        update();
    });

    this->before = new Before();
    this->play01 = new Play01();
    this->play02 = new Play02();
    this->play03 = new Play03();
    // this->bullet = new Bullet();
    this->map = new Map();
    this->over = new Over(this);
    // 接收OVER类中返回主菜单信号，点击按钮后切换到主菜单状态（status=0）
    connect(over, &Over::backToMainMenu, this, [](){
        Widget::status = 0;
    });
    this->startTimer(20);//1秒后触发 某个函数
}

void Widget::timerEvent(QTimerEvent *event)
{
    // qDebug()<<"呵呵";
    this->update();
    if(status==1){
        play01->enemyToScene();
        play01->collisionDetection();

    }
    if (status == 3) {
        play03->enemyToScene();
        play03->collisionDetection();

    }
}

int Widget::getRandomInt()
{
    // 生成 0-7 之间的随机整数并返回
    int ranInt = std::rand() % 7+1;
    return ranInt;
}

void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    //
    if(Widget::status == 0){
        before->draw(painter);
        btn1->setVisible(true);
        btn2->setVisible(true);
        btn3->setVisible(true);
        over->backBtn->setVisible(false);        // 显示按钮
    }
    else if(Widget::status == 1){
        btn2->setVisible(false);        // 隐藏按钮
        btn1->setVisible(false);
        btn3->setVisible(false);
        over->backBtn->setVisible(false);
        //根据得分切换地图
        if(play01->Count>=10&&map->level==1) {
            map->level=2;
            map->reloadMap();
        }
        map->draw(painter);
        map->map_pos();
        play01->draw(painter);
    }
    else if(Widget::status == 2){
        btn2->setVisible(false);        // 隐藏按钮
        btn1->setVisible(false);
        btn3->setVisible(false);
        map->draw(painter);
        map->map_pos();
        play02->draw(painter);
    }
    else if (Widget::status == -2 || Widget::status == -3) {
        // 显示胜利结果（传递status给over->draw）
        over->draw(painter, Widget::status);
    }
    else if(Widget::status == -1){
        btn2->setVisible(false); // 隐藏按钮
        btn1->setVisible(false);
        btn3->setVisible(false);
        over->draw(painter,play01->Count);
    }
    else if (status == 3) {
        btn2->setVisible(false); // 隐藏按钮
        btn1->setVisible(false);
        btn3->setVisible(false);
        over->backBtn->setVisible(false);
        map->draw(painter);
        map->map_pos();
        play03->draw(painter);
    }


}

void Widget::keyPressEvent(QKeyEvent *event)
{
    if(Widget::status==0){
        before->keyPressEvent(event);
    }
    else if(Widget::status==1){
        play01->keyPressEvent(event);
    }
    else if (status == 2) {
        play02->keyPressEvent(event);
    }
    else if(Widget::status==-1){
        over->keyPressEvent(event);
    }
    else if (status == 3) {
        play03->keyPressEvent(event);
    }
}

void Widget::keyReleaseEvent(QKeyEvent *event)
{
    if(Widget::status==0){
        before->keyReleaseEvent(event);
    }
    else if(Widget::status==1){
        play01->keyReleaseEvent(event);
    }
    else if (status == 2) {
        play02->keyReleaseEvent(event);
    }
    else if(Widget::status==-1){
        over->keyReleaseEvent(event);
    }
     else if (status == 3) {
        play03->keyReleaseEvent(event);
    }
    }
Widget::~Widget()
{
    delete ui;
    delete before;
    delete play01;
    delete play02;
    delete play03;
    delete over;
    delete map;
}


