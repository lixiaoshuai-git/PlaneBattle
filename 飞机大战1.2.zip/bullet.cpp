#include "bullet.h"

Bullet::Bullet() {
    bullet.load(":/new/res/bullet_12.png");
    rect.setWidth(bullet.width()-2);
    rect.setHeight(bullet.height()-2);
    rect.moveTo(bullet_x,bullet_y);
}
void Bullet::bullet_pos()
{
    if(is_free){
        return;
    }
    else{
        bullet_y-=bullet_speed;
        rect.moveTo(bullet_x,bullet_y);
    }
}
void Bullet::draw(QPainter& painter)
{
    if(!is_free){
    painter.drawPixmap(bullet_x,bullet_y,bullet);
    }
}

