#include "music.h"

Music::Music():QSoundEffect()
{
    bgMusic->setSource(bg);
    bombMusic->setSource(bomb);
    bossMusic->setSource(boss);

}

void Music::playbackMusic(QSoundEffect * music,float volume)
{
    music->setLoopCount(QSoundEffect::Infinite);
    music->setVolume(volume);
    music->play();
}

void Music::stopMusic(QSoundEffect * music)
{
    music->stop();
}
void Music::playbombEffect()
{
    bombMusic->setVolume(1);
    bombMusic->play();
}
