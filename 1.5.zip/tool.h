#ifndef TOOL_H
#define TOOL_H

class Tool
{
public:
    Tool();
};

#endif // TOOL_H
