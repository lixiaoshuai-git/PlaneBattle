#ifndef MUSIC_H
#define MUSIC_H
#include <QSoundEffect>

class Music: public QSoundEffect
{
public:
    Music();
    QSoundEffect * bgMusic= new QSoundEffect() ;
    QSoundEffect * bombMusic =new QSoundEffect();
    QSoundEffect * bossMusic =new QSoundEffect();

    QUrl bg = QUrl::fromLocalFile(":/new/res/bg.wav");
    QUrl bomb = QUrl::fromLocalFile(":/new/res/bomb.wav");
    QUrl boss = QUrl::fromLocalFile(":/new/res/boss.wav");

    float bgv=0.5;
    float bossv=0.8;

    void playbackMusic(QSoundEffect * music,float volume);
    void stopMusic(QSoundEffect * music);
    void playbombEffect();

};

#endif // MUSIC_H
