#include "bomb.h"
#include <qpainter>
Bomb::Bomb() {
    image.load(":/new/res/bomb-2.png");
    x=0;
    y=0;
    m_Recoder =0;

}

void Bomb::draw(QPainter &painter)
{
    painter.drawPixmap(x,y,image);
}
void Bomb::updateInfo()
{
    //空闲状态
    if(free)
    {
        return;
    }

    m_Recoder++;
    if(m_Recoder < BOMB_INTERVAL)
    {
        //记录爆炸间隔未到，直接return，不需要切图
        return;
    }
    //重置记录
    m_Recoder = 0;


}
