#include "Play02.h"
#include <QPixmap>
#include "plane.h"
#include "widget.h"
#include <QPainter>
#include <ctime>
Play02::Play02()
{
    this->plane1 = new Plane();
    this->plane2 = new Plane();
    plane1->image.load(":/new/res/hero.png");
    plane2->image.load(":/new/res/hero2.png");
    // 初始位置区分
    plane1->x = 150;
    plane1->y = 600;
    plane1->hp = plane1->maxHp = 100;

    plane2->x = 300;
    plane2->y = 600;
    plane2->hp = plane2->maxHp = 100;

}
Play02::~Play02()
{
    delete plane1;
    delete plane2;
}

void Play02::draw(QPainter &painter)
{
    // 只在血量 > 0 时绘制飞机
    if (plane1-> isAlive) {
        plane1->drawPlayer2(painter);
    }
    if (plane2->isAlive) {
        plane2->draw(painter);
    }

    for(int i = 0 ; i< ENEMY_NUM;i++)
    {
        if(m_enemys[i].free == false)
        {
            m_enemys[i].shoot(); // 调用发射函数
            m_enemys[i].draw(painter);
        }
    }
    for(int i = 0 ; i < BOMB_NUM;i++)
    {
        if(m_bombs[i].free == false)
        {
            m_bombs[i].draw(painter);
            m_bombs[i].free =true;
        }
    }

}

void Play02::keyPressEvent(QKeyEvent *event)
{
    int code = event->key();
    if (plane1->isAlive){
        // ===== 玩家1 =====
        if (code == Qt::Key_W) plane1->isUp    = true;
        if (code == Qt::Key_S) plane1->isDown  = true;
        if (code == Qt::Key_A) plane1->isLeft  = true;
        if (code == Qt::Key_D) plane1->isRight = true;
        if (code == Qt::Key_E) plane1->isFire = true;
    }
    // ===== 玩家2 =====
    if (plane2->isAlive){
        if (code == Qt::Key_8)  plane2->isUp    = true;
        if (code == Qt::Key_5)  plane2->isDown  = true;
        if (code == Qt::Key_4)  plane2->isLeft  = true;
        if (code == Qt::Key_6)  plane2->isRight = true;
        if (code == Qt::Key_0 || code == Qt::Key_Enter) plane2->isFire = true;
    }
}

void Play02::keyReleaseEvent(QKeyEvent *event)
{
    int code = event->key();
    // ===== 玩家1 =====
    if (plane1->isAlive){
        if (code == Qt::Key_W) plane1->isUp    = false;
        if (code == Qt::Key_S) plane1->isDown  = false;
        if (code == Qt::Key_A) plane1->isLeft  = false;
        if (code == Qt::Key_D) plane1->isRight = false;
    }

    // ===== 玩家2 =====
    if (plane2->isAlive){
        if (code == Qt::Key_8)  plane2->isUp    = false;
        if (code == Qt::Key_5)  plane2->isDown  = false;
        if (code == Qt::Key_4)  plane2->isLeft  = false;
        if (code == Qt::Key_6)  plane2->isRight = false;
        if (code == Qt::Key_0 || code == Qt::Key_Enter) plane2->isFire = false;
    }
}
void Play02::enemyToScene()
{
    m_recorder++;
    if(m_recorder < ENEMY_INTERVAL)
    {
        return;
    }

    m_recorder = 0;

    for(int i = 0 ; i< ENEMY_NUM;i++)
    {
        if(m_enemys[i].free)
        {
            //敌机空闲状态改为false
            m_enemys[i].free = false;
            //设置坐标
            m_enemys[i].x = rand() % (WIN_W - m_enemys[i].rect.width());
            m_enemys[i].y = -m_enemys[i].rect.height();
            break;
        }
    }
}
void Play02::collisionDetection()
{
    //遍历所有非空闲的敌机
    for(int i = 0 ;i < ENEMY_NUM;i++)
    {
        if(m_enemys[i].free)
        {
            //空闲飞机 跳转下一次循环
            continue;
        }
        if (plane1->isAlive){
            foreach (Bullet* bullet1, plane1->bullets) {
                if(bullet1->is_free){
                    continue;
                }
                if(m_enemys[i].rect.intersects(bullet1->rect))
                {
                    m_enemys[i].free = true;
                    bullet1->is_free = true;

                    //播放爆炸效果
                    for(int k = 0 ; k < BOMB_NUM;k++)
                    {
                        if(m_bombs[k].free)
                        {
                            m_bombs[k].free = false;
                            //更新坐标
                            m_bombs[k].x = m_enemys[i].x;
                            m_bombs[k].y = m_enemys[i].y;
                            break;
                        }
                    }
                }
            }
        }
        for(int i = 0; i < ENEMY_NUM; i++) {
            if(m_enemys[i].free) continue;

            // 遍历该敌机的所有子弹
            if (plane1->isAlive){
                foreach (EnemyBullet* bullet, m_enemys[i].bullets) {
                    if (bullet->is_free) continue;

                    // 检测子弹是否击中玩家飞机
                    if (plane1->rect.intersects(bullet->rect)) {
                        bullet->is_free = true;
                        // 触发玩家飞机爆炸（根据需求设置游戏结束或扣血）
                        plane1->hp -= 20; // 每次击中减少20血
                        if (plane1->hp <= 0) {
                            plane1->hp = 0;
                            plane1->isAlive = false; // 标记为死亡
                        }
                        if (plane1->hp <= 0 && plane2->hp <= 0){
                            Widget::status = -1; // 血量为0时游戏结束
                        }
                    }
                }
            }
        }
        if(m_enemys[i].free)
        {
            //空闲飞机 跳转下一次循环
            continue;
        }
        if (plane2->isAlive){
            foreach (Bullet* bullet1, plane2->bullets) {
                if(bullet1->is_free){
                    continue;
                }
                if(m_enemys[i].rect.intersects(bullet1->rect))
                {
                    m_enemys[i].free = true;
                    bullet1->is_free = true;

                    //播放爆炸效果
                    for(int k = 0 ; k < BOMB_NUM;k++)
                    {
                        if(m_bombs[k].free)
                        {
                            m_bombs[k].free = false;
                            //更新坐标
                            m_bombs[k].x = m_enemys[i].x;
                            m_bombs[k].y = m_enemys[i].y;
                            break;
                        }
                    }
                }
            }
        }
        for(int i = 0; i < ENEMY_NUM; i++) {
            if(m_enemys[i].free) continue;

            // 遍历该敌机的所有子弹
            if (plane2->isAlive){
                foreach (EnemyBullet* bullet, m_enemys[i].bullets) {
                    if (bullet->is_free) continue;

                    // 检测子弹是否击中玩家飞机
                    if (plane2->rect.intersects(bullet->rect)) {
                        bullet->is_free = true;
                        // 触发玩家飞机爆炸（根据需求设置游戏结束或扣血）
                        plane2->hp -= 20; // 每次击中减少20血
                        if (plane2->hp <= 0) {
                            plane2->hp = 0;
                            plane2->isAlive = false; // 标记为死亡
                        }
                        if (plane1->hp <= 0 && plane2->hp <= 0){
                            Widget::status = -1; // 血量为0时游戏结束
                        }
                    }
                }
            }
        }
    }
}

