#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include"before.h"
#include"play01.h"
#include"over.h"
#include "map.h"
#include "play03.h"
#include "play02.h"
#include <QPushButton>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    static int status;
    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;
    explicit Widget(QWidget *parent = 0);
    void paintEvent(QPaintEvent *painter);
    int getRandomInt();
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);// alt +回车
    void timerEvent(QTimerEvent *event);
    Before *before = nullptr;
    Play01 *play01 = nullptr;
    Play02 *play02 = nullptr;
    Play03 *play03 = nullptr;
    Over *over = nullptr;
    Map *map = nullptr;
    ~Widget();



private:
    Ui::Widget *ui;
};


#endif // WIDGET_H
