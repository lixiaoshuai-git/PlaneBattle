#ifndef BOMB_H
#define BOMB_H
#include "config.h"
#include <QPixmap>
#include <QVector>

class Bomb
{
public:
    Bomb();
    void draw(QPainter& painter);
    //更新信息（播放图片下标、播放间隔）
    void updateInfo();

public:

    //放爆炸资源数组
    QPixmap image;

    //爆炸位置
    int x;
    int y;

    //爆炸状态
    bool free=true;

    //爆炸切图的时间间隔
    int m_Recoder;

    //爆炸时加载的图片下标

};

#endif // BOMB_H
