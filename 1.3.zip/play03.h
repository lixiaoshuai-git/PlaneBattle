#ifndef PLAY03_H
#define PLAY03_H

#include <QPainter>
#include <QKeyEvent>
#include "plane.h"
#include "enemy.h"
#include "bomb.h"

class Play03
{
public:
    Play03();
    ~Play03();
    void draw(QPainter &painter);
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);

    void enemyToScene();
    void collisionDetection();
    void enemycollision(Plane * plane);//小兵的collisiondetection函数
    void judgewhoWin();//判断谁赢

    Plane *plane1 = nullptr;   // 玩家1
    Plane *plane2 = nullptr;   // 玩家2

    Enemy  m_enemys[ENEMY_NUM];
    Bomb   m_bombs[BOMB_NUM];
    int    m_recorder = 0;
    int    Count1;
    int    Count2;
};

#endif // PLAY03_H
