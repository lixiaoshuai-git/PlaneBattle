#include "widget.h"
#include <ctime>

#include <QApplication>

int main(int argc, char *argv[])
{
    srand((unsigned int)time(nullptr)); // 用系统时间初始化种子
    QApplication a(argc, argv);
    Widget w;
    w.show();
    return a.exec();
}
